class MusicPlayer {
  static void play(String song) {
    print('Playing song: $song');
  }

  static void pause() {
    print('Music paused');
  }

  static void stop() {
    print('Music stopped');
  }
}
