class WeatherForecast {
  static String getForecast(String city) {
    return 'The weather in $city is sunny with a chance of clouds.';
  }

  static String getTemperature(String city) {
    return 'The temperature in $city is 25°C.';
  }
}
